# Why is this there?
# See https://github.com/pypa/pip/issues/3969#issuecomment-247381915
manylinux1_compatible = True
