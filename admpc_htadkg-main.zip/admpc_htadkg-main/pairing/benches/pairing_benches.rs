#![feature(test)]

extern crate ff;
extern crate pairing;
extern crate rand;
extern crate test;

mod bls12_381;
