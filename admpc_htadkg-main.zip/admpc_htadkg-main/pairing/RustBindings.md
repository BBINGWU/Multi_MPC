Spec:

TODO:
1. Generate random G1/G2/GT generator. [DONE]
2. Generate deterministic G1/G2/GT from string.
3. pairings(G1,G2) [DONE]
4. Functions for multiplication and exponentiation of G1/G2/GT elememts
5. Generate random field element. [DONE]
6. Addition and multiplication of field elements. [DONE]
7. Exponentiation function that exponentiates a G1/G2/GT element by a field element.


