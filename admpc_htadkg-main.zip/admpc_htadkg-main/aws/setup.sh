#!/bin/bash

# apt-get update
# curl -fsSL https://get.docker.com -o get-docker.sh
# sh get-docker.sh

# Uncomment this for drand
# sudo apt install make
# sudo apt-get -y install build-essential
# sudo add-apt-repository ppa:longsleep/golang-backports
# sudo apt update
# sudo apt install golang-go